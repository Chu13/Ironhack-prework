var rover = {
  direction: "N",
  x : 0,
  y : 0,
  travelLog: ["0,0"]
};
// ======================
function turnLeft(){
  switch (rover.direction) {
    case "N":
      rover.direction = "W"
      break;
    case "W":
       rover.direction = "S"
       break;
    case "S":
       rover.direction = "E"
       break;
    case "E":
       rover.direction = "N"
       break;
    default:
    console.log ("Rover didn't turn")

  }
  console.log("turnLeft was called!");
}

function turnRight(){
  switch (rover.direction) {
    case "N":
      rover.direction = "E"
      break;
    case "E":
      rover.direction = "S"
      break;
    case "S":
      rover.direction = "W"
      break;
    case "W":
      rover.direction = "N"
      break;
    default:
      console.log("Rover didn't turn")
  }
  console.log("turnRight was called!");
}

function moveForward(){
  if (rover.x <= 0 && rover.direction === "W") {
    console.log("Can't get out of the grid");
  }
  else if (rover.x >= 10 && rover.direction === "E") {
    console.log("Can't get out of the grid");
  }
  else if (rover.y <= 0 && rover.direction === "N") {
    console.log("Can't get out of the grid");
  }
  else if (rover.y >=10 && rover.direction === "S") {
    console.log("Can't get out of the grid");
  }
  else {

  switch (rover.direction) {
    case "N":
      rover.y -= 1
      break;
    case "W":
      rover.x -= 1
      break;
    case "S":
      rover.y += 1
      break;
    case "E":
      rover.x += 1
      break;
    default:
      console.log("Didn't moved forward");
  }
    console.log("moveForward was called")
  rover.travelLog.push(rover.x + "," + rover.y);
}
  console.log(rover.travelLog);
}

function move(direction) {
  for (var i = 0; i < direction.length; i++) {
    if (direction[i] === "f" || direction[i] === "F") {
      moveForward();
    }
    else if (direction[i] === "r" || direction[i] === "R") {
      turnRight();
    }
    else if (direction[i] === "l" || direction[i] === "L") {
      turnLeft();
    }
    else if (direction[i] === "b" || direction[i] === "B") {
      moveBackwards();
    }
    else {
      console.log("Rover didn't moved or turned");
    }
  }
}

function moveBackwards() {
  if (rover.x <= 0 && rover.direction === "E") {
    console.log("Can't get out of the grid");
  }
  else if (rover.x >= 10 && rover.direction === "W") {
    console.log("Can't get out of the grid");
  }
  else if (rover.y <= 0 && rover.direction === "S") {
    console.log("Can't get out of the grid");
  }
  else if (rover.y >= 10 && rover.direction === "N") {
    console.log("Can't get out of the grid");
  }
  else{
  switch (rover.direction) {
    case "N":
      rover.y += 1
      break;
    case "W":
      rover.x += 1
      break;
    case "S":
      rover.y -= 1
      break;
    case "E":
      rover.x -= 1
      break;
    default:
    console.log("Didn't moved backwards");
    }
      console.log("moveBackwards was called");
      rover.travelLog.push(rover.x + "," + rover.y);
  }
    console.log(rover.travelLog);
}
